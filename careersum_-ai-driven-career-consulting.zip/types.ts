
export interface Service {
  title: string;
  description: string;
}

export interface AdvantagePoint {
  id: number;
  title: string;
  description: string;
}
